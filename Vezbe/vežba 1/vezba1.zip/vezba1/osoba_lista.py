def prikazi_osobu(osoba):
    print()
    print("\n".join([
        "{:>12}: {}".format("JMBG", osoba["jmbg"]),
        "{:>12}: {}".format("Ime", osoba["ime"]),
        "{:>12}: {}".format("Prezime", osoba["prezime"]),
        "{:>12}: {}".format("God. rođenja", osoba["god_rodjenja"])
    ]))


def prikazi_osobe(osobe):
    format_linije = "{:13} {:10} {:10} {:12}"

    print()
    # zaglavlje
    print(format_linije.format("JMBG", "Ime", "Prezime", "God. rođenja"))
    print("{} {} {} {}".format("-"*13, "-"*10, "-"*10, "-"*12))
    # sadržaj
    for osoba in osobe:
        print(format_linije.format(osoba["jmbg"], osoba["ime"], osoba["prezime"], osoba["god_rodjenja"]))


def pronadji_osobu(osobe, jmbg):
    for osoba in osobe:
        if osoba["jmbg"] == jmbg:
            return osoba


format_unosa = "{:>20}: "


def unesi_promenljive_podatke_osobe():
    ime = ""
    while len(ime) < 2 or len(ime) > 10:
        ime = input(format_unosa.format("Unesite ime"))

    prezime = ""
    while len(prezime) < 2 or len(prezime) > 10:
        prezime = input(format_unosa.format("Unesite prezime"))

    godina_rodjenja = 1899
    while godina_rodjenja < 1900 or godina_rodjenja > 2019:
        try:
            godina_rodjenja = int(input(format_unosa.format("Unesite god. rođenja")))
        except ValueError:
            pass

    return ime, prezime, godina_rodjenja


def unesi_osobu(osobe):
    print()
    print("Unos osobe...")

    print()

    jmbg = ""
    while jmbg == "" or len(jmbg) != 13 or not jmbg.isdigit() or pronadji_osobu(osobe, jmbg):
        jmbg = input(format_unosa.format("Unesite JMBG"))

    ime, prezime, god_rodjenja = unesi_promenljive_podatke_osobe()
    osoba = {
        "jmbg": jmbg,
        "ime": ime,
        "prezime": prezime,
        "god_rodjenja": god_rodjenja
    }
    osobe.append(osoba)


def izmeni_osobu(osobe):
    print()
    print("Izmena osobe...")

    print()

    osoba = None
    while osoba is None:
        jmbg = input(format_unosa.format("Unesite JMBG"))
        osoba = pronadji_osobu(osobe, jmbg)

    ime, prezime, god_rodjenja = unesi_promenljive_podatke_osobe()
    osoba["ime"] = ime
    osoba["prezime"] = prezime
    osoba["god_rodjenja"] = god_rodjenja


def obrisi_osobu(osobe):
    print()
    print("Brisanje osobe...")

    print()
    jmbg = input(format_unosa.format("Unesite JMBG"))

    for it in range(len(osobe)):
        osoba = osobe[it]
        if osoba["jmbg"] == jmbg:
            del osobe[it]
            break


def test():
    # rečnici koji grupišu podatke o osobama u strukture
    osoba1 = {
        "jmbg": "1111111111111",
        "ime": "Aaa",
        "prezime": "Aaa",
        "god_rodjenja": 2001
    }
    osoba2 = {
        "jmbg": "2222222222222",
        "ime": "Bbb",
        "prezime": "Bbb",
        "god_rodjenja": 2002
    }
    osoba3 = {
        "jmbg": "3333333333333",
        "ime": "Ccc",
        "prezime": "Ccc",
        "god_rodjenja": 2003
    }

    prikazi_osobu(osoba1)
    prikazi_osobu(osoba2)
    prikazi_osobu(osoba3)

    # predefinisana lista osoba
    osobe = [
        osoba1,
        osoba2,
        osoba3
    ]
    prikazi_osobe(osobe)

    unesi_osobu(osobe)
    prikazi_osobe(osobe)

    izmeni_osobu(osobe)
    prikazi_osobe(osobe)

    obrisi_osobu(osobe)
    prikazi_osobe(osobe)


# da li se modul pokreće samostalno, tj. da li nije import-ovan?
if __name__ == "__main__":
    test()
