# arhiva DICOM snimaka: ftp://medical.nema.org/medical/dicom/datasets/wg04/

from tkinter import *
from tkinter import ttk
import pydicom
import pydicom_PIL
from PIL import Image, ImageTk

class DICOMProzor(Tk):

    def starostValidacija(self):
        try:
            starost = int(self.__starost.get())
            if starost < 0 or starost > 999:
                messagebox.showerror("Greška", "Starost mora biti u rasponu od 0 do 999!")
                return None
        except:
            messagebox.showerror("Greška", "Godina mora biti ceo broj!")
            return None

        return starost

    def postaviStanjeStarostPanela(self, stanje):
        for podelement in self.__starostPanel.winfo_children(): # iteracija kroz podelemente widget-a
            podelement["state"] = stanje

    def klikNaPacijentPrisutanDugme(self):
        stanje = NORMAL if self.__pacijentPrisutan.get() else DISABLED
        self.__pacijentEntry["state"] = stanje

    def klikNaPolPrisutanDugme(self):
        # readonly stanje Combobox-a podrazumeva uključeno stanje, takvo da korisnik može samo da bira ponuđene vrednosti, ali ne i da ih unosi sa tastature
        stanje = "readonly" if self.__polPrisutan.get() else DISABLED
        self.__polCombobox["state"] = stanje

    def klikNaStarostPrisutnaDugme(self):
        stanje = NORMAL if self.__starostPrisutna.get() else DISABLED
        self.postaviStanjeStarostPanela(stanje)

    def azurirajStanja(self):
        self.klikNaPacijentPrisutanDugme()
        self.klikNaPolPrisutanDugme()
        self.klikNaStarostPrisutnaDugme()

    def klikNaOtvoriDugme(self):
        try:
            # otvaranje dijalog prozora za odabir datoteke
            stazaDoDatoteke = filedialog.askopenfilename(
                initialdir = "./DICOM samples",
                title = "Otvaranje",
                filetypes = [("DICOM files", "*.dcm"), ("All files", "*.*")])
            if stazaDoDatoteke == "": # korisnik otkazao dijalog?
                return

            # otvaranje može da potraje; postaviti kursor miša na čekajući
            self["cursor"] = "wait"
            self.update()

            self.__stazaDoDatoteke = stazaDoDatoteke # pamćenje staze do datoteke radi čuvanja
            self.__dataset = pydicom.read_file(self.__stazaDoDatoteke, force = True) # otvaranje DICOM datoteke; force parametar obezbeđuje čitanje nepotpunih datoteka
            print(self.__dataset)

            self.title(self.__stazaDoDatoteke)
            # omogućavanje interfejsa za izmenu i čuvanje
            self.__pacijentPrisutanCheckbutton["state"] = NORMAL
            self.__polPrisutanCheckbutton["state"] = NORMAL
            self.__starostPrisutnaCheckbutton["state"] = NORMAL
            self.__ocistiDugme["state"] = NORMAL
            self.__sacuvajDugme["state"] = NORMAL
            self.__fileMeni.entryconfig(2, state = NORMAL)
            self.__fileMeni.entryconfig(3, state = NORMAL)

            # podaci DICOM datoteke ne moraju da postoje
            if "PatientName" in self.__dataset: # da li podatak postoji u dataset-u?
                self.__pacijent.set(self.__dataset.PatientName) # vrednost podatka
                self.__pacijentPrisutan.set(True) # podatak pronađen?
            else:
                self.__pacijentPrisutan.set(False)

            if "PatientSex" in self.__dataset:      
                for vrednost, tekst in [("M", "muški"), ("F", "ženski"), ("O", "drugi")]: # 3 moguće vrednosti: M, F, O
                    if vrednost == self.__dataset.PatientSex:
                        self.__pol.set(tekst)
                        break
                self.__polPrisutan.set(True)
            else:
                self.__polPrisutan.set(False)

            if "PatientAge" in self.__dataset:
                try:
                    self.__starost.set(int(self.__dataset.PatientAge[:-1])) # sve do poslednjeg karaktera je vrednost
                    self.__starostJedinica.set(self.__dataset.PatientAge[-1]) # poslednji karakter je jedinica mere; Y, M, W, D
                    self.__starostPrisutna.set(True)
                except ValueError: # možda podatak postoji, ali ne može da se parsira u int
                    pass
            else:
                self.__starostPrisutna.set(False)

            self.azurirajStanja() # omogućavanje polja za izmenu na osnovu pročitanih podataka

            pilSlika = pydicom_PIL.get_PIL_image(self.__dataset) # pokušaj dekompresije i čitanja slike iz dataset objekta
            sirina = pilSlika.width
            visina = pilSlika.height
            print("originalne dimenzije:", sirina, ",", visina)

            maksDimenzija = 900
            if sirina > maksDimenzija or visina > maksDimenzija:
                if sirina > visina: # smanjiti sliku po većoj od 2 dimenzije
                    odnos = maksDimenzija/sirina
                    sirina = maksDimenzija
                    visina = int(odnos*visina) # manja dimenzija se smanjuje proporcionalno
                else:
                    odnos = maksDimenzija/visina
                    sirina = int(odnos*sirina) # manja dimenzija se smanjuje proporcionalno
                    visina = maksDimenzija
            print("nove dimenzije:", sirina, ",", visina)
            pilSlika = pilSlika.resize((sirina, visina), Image.LANCZOS) # LANCZOS metoda je najbolja za smanjivanje slike

            slika = ImageTk.PhotoImage(pilSlika) # PIL slika se mora prevesti u TkInter sliku (ImageTk)
            self.__slikaLabela["image"] = slika
            self.__slikaLabela.image = slika
        except: # desila se greška; reset-ovanje slike na podrazumevanu
            # PIL slika se mora prevesti u TkInter sliku (ImageTk)
            #slika = ImageTk.PhotoImage(Image.new('L', (200, 200))) # crna slika dimenzija 200x200 piksela
            slika = ImageTk.PhotoImage(Image.open("DICOM-Logo.jpg")) # bilo koja druga podrazumevana slika
            self.__slikaLabela["image"] = slika  # labeli se dodeljuje slika
            self.__slikaLabela.image = slika  # referenca na TkInter sliku se mora sačuvati, inače nece biti prikazana!

        self["cursor"] = "" # reset-ovanje pokazivača miša na podrazumevani

    def klikNaOcistiDugme(self):
        self.__pacijent.set("")
        self.__pol.set("muški")
        self.__starost.set(0)
        self.__starostJedinica.set("Y")

    def sacuvaj(self):
        self["cursor"] = "wait"
        self.update()

        if self.__pacijentPrisutan.get(): # podatak zadržan?
            self.__dataset.PatientName = self.__pacijent.get() # vrednost podatka
        elif "PatientName" in self.__dataset:
            del self.__dataset.PatientName # brisanje podatka iz dataset-a

        if self.__polPrisutan.get():
            for vrednost, tekst in [("M", "muški"), ("F", "ženski"), ("O", "drugi")]:
                if tekst == self.__pol.get():
                    self.__dataset.PatientSex = vrednost
                    break
        elif "PatientSex" in self.__dataset:
            del self.__dataset.PatientSex

        if self.__starostPrisutna.get():
            starost = self.starostValidacija()
            if starost is None:
                return

            self.__dataset.PatientAge = "{:03d}{:}".format(starost, self.__starostJedinica.get())
        elif "PatientAge" in self.__dataset:
            del self.__dataset.PatientAge

        print(self.__dataset)

        self.__dataset.save_as(self.__stazaDoDatoteke) # čuvanje dataset-a; ako ne postoji, biće kreiran

        self["cursor"] = ""

    def klikNaSacuvajDugme(self):
        self.sacuvaj()

    def klikNaSacuvajKaoDugme(self):
        try:
            # otvaranje dijalog prozora za odabir datoteke
            stazaDoDatoteke = filedialog.asksaveasfilename(
                initialdir = "./DICOM samples",
                title = "Čuvanje",
                filetypes = [("DICOM files", "*.dcm")],
                defaultextension = ".dcm")
            if stazaDoDatoteke == "":
                return

            self.__stazaDoDatoteke = stazaDoDatoteke
            self.sacuvaj()

            self.title(self.__stazaDoDatoteke)
        except:
            pass

    def klikNaIzlazDugme(self):
        if messagebox.askquestion("Upozorenje", "Da li ste sigurni?", icon = "warning") == "yes":
            self.destroy()

    def klikNaOProgramuDugme(self):
        messagebox.showinfo("DICOM v1.0", "Program za prikaz i izmenu DICOM datoteka.")

    def napraviGUI(self):
        meniBar = Menu(self)
        self["menu"] = meniBar

        self.__fileMeni = Menu(meniBar, tearoff = 0)
        self.__fileMeni.add_command(label = "Otvori...", command = self.klikNaOtvoriDugme)
        self.__fileMeni.add_separator()
        self.__fileMeni.add_command(label = "Sacuvaj", command = self.klikNaSacuvajDugme, state = DISABLED)
        self.__fileMeni.add_command(label = "Sacuvaj kao...", command = self.klikNaSacuvajKaoDugme, state = DISABLED)
        self.__fileMeni.add_separator()
        self.__fileMeni.add_command(label = "Izlaz", command = self.klikNaIzlazDugme)
        meniBar.add_cascade(label = "Datoteka", menu = self.__fileMeni)

        helpMeni = Menu(meniBar, tearoff = 0)
        helpMeni.add_command(label = "O programu...", command = self.klikNaOProgramuDugme)
        meniBar.add_cascade(label = "Pomoć", menu = helpMeni)

        #slika = ImageTk.PhotoImage(Image.new('L', (200, 200)))
        slika = ImageTk.PhotoImage(Image.open("DICOM-Logo.jpg"))

        self.__slikaLabela = Label(self, image = slika)
        self.__slikaLabela.image = slika
        self.__slikaLabela.pack(side = LEFT, expand = 1)

        panelZaUnos = Frame(self, borderwidth = 2, relief = "ridge", padx = 10, pady = 10)
        panelZaUnos.pack(side = RIGHT, fill = BOTH, expand = 1)

        self.__pacijentPrisutanCheckbutton = Checkbutton(panelZaUnos, variable = self.__pacijentPrisutan, command = self.klikNaPacijentPrisutanDugme, state = DISABLED)
        self.__polPrisutanCheckbutton = Checkbutton(panelZaUnos, variable = self.__polPrisutan, command = self.klikNaPolPrisutanDugme, state = DISABLED)
        self.__starostPrisutnaCheckbutton = Checkbutton(panelZaUnos, variable = self.__starostPrisutna, command = self.klikNaStarostPrisutnaDugme, state = DISABLED)

        self.__ocistiDugme = Button(panelZaUnos, text = "Očisti", width = 10, command = self.klikNaOcistiDugme, state = DISABLED)

        self.__pacijentEntry = Entry(panelZaUnos, textvariable = self.__pacijent, state = DISABLED)
        self.__polCombobox = ttk.Combobox(panelZaUnos, values = ("muški", "ženski", "drugi"), textvariable = self.__pol, state = DISABLED)

        self.__starostPanel = Frame(panelZaUnos)
        Spinbox(self.__starostPanel, from_ = 0, to = 999, textvariable = self.__starost, state = DISABLED).pack(side = LEFT)
        for vrednost, tekst in [("Y", "godina"), ("M", "meseci"), ("W", "nedelja"), ("D", "dana")]:
            Radiobutton(self.__starostPanel, value = vrednost, text = tekst, variable = self.__starostJedinica, state = DISABLED).pack(side = LEFT)

        self.__sacuvajDugme = Button(panelZaUnos, text = "Sačuvaj", width = 10, command = self.klikNaSacuvajDugme, state = DISABLED)

        red = 1;
        self.__pacijentPrisutanCheckbutton.grid(row = red); red += 1
        self.__polPrisutanCheckbutton.grid(row = red); red += 1
        self.__starostPrisutnaCheckbutton.grid(row = red); red += 1

        red = 1; kolona = 1
        Label(panelZaUnos, text = "Pacijent:").grid(row = red, column = kolona, sticky = E); red += 1
        Label(panelZaUnos, text = "Pol:").grid(row = red, column = kolona, sticky = E); red += 1
        Label(panelZaUnos, text = "Starost:").grid(row = red, column = kolona, sticky = E); red += 1

        red = 0; kolona = 2
        self.__ocistiDugme.grid(row = red, column = kolona, sticky = W); red += 1
        self.__pacijentEntry.grid(row = red, column = kolona, sticky = W); red += 1
        self.__polCombobox.grid(row = red, column = kolona, sticky = W); red += 1
        self.__starostPanel.grid(row = red, column = kolona, sticky = W); red += 1
        self.__sacuvajDugme.grid(row = red, column = kolona, sticky = W); red += 1

        self.title("DICOM")

    def __init__(self):
        super().__init__()

        self.__pacijentPrisutan = BooleanVar(self, False)
        self.__pacijent = StringVar(self)

        self.__polPrisutan = BooleanVar(self, False)
        self.__pol = StringVar(self, "muški")

        self.__starostPrisutna = BooleanVar(self, False)
        self.__starost = IntVar(self)
        self.__starostJedinica = StringVar(self, "Y")

        self.napraviGUI()

        self.update_idletasks()
        sirina = self.winfo_width()
        visina = self.winfo_height()
        self.minsize(sirina, visina)
        #self.maxsize(1280, 720)

        self.focus_force()

def test():
    dicomProzor = DICOMProzor()
    dicomProzor.mainloop()

if __name__ == "__main__":
    test()
