from datetime import datetime


godina = datetime.now().year


def izracunaj_starost(osoba):
    return godina - osoba["god_rodjenja"]


def prikazi_osobu(osoba):
    print()
    print("\n".join([
        "{:>12}: {}".format("JMBG", osoba["jmbg"]),
        "{:>12}: {}".format("Ime", osoba["ime"]),
        "{:>12}: {}".format("Prezime", osoba["prezime"]),
        "{:>12}: {}".format("God. rođenja", osoba["god_rodjenja"]),
        "{:>12}: {}".format("starost", izracunaj_starost(osoba))
    ]))


def prikazi_osobe(osobe):
    format_linije = "{:13} {:10} {:10} {:12} {:7}"

    print()
    # zaglavlje
    print(format_linije.format("JMBG", "Ime", "Prezime", "God. rođenja", "Starost"))
    print("{} {} {} {} {}".format("-"*13, "-"*10, "-"*10, "-"*12, "-"*7))
    # sadržaj
    for jmbg in sorted(osobe):
        osoba = osobe[jmbg]
        print(format_linije.format(osoba["jmbg"], osoba["ime"], osoba["prezime"], osoba["god_rodjenja"], izracunaj_starost(osoba)))


def pronadji_osobu(osobe, jmbg):
    return osobe.get(jmbg)  # vraća None ako ključ nije ponađen; zaobilazi KeyError


format_unosa = "{:>20}: "


def unesi_promenljive_podatke_osobe():
    ime = ""
    while len(ime) < 2 or len(ime) > 10:
        ime = input(format_unosa.format("Unesite ime"))

    prezime = ""
    while len(prezime) < 2 or len(prezime) > 10:
        prezime = input(format_unosa.format("Unesite prezime"))

    godina_rodjenja = 1899
    while godina_rodjenja < 1900 or godina_rodjenja > 2019:
        try:
            godina_rodjenja = int(input(format_unosa.format("Unesite god. rođenja")))
        except ValueError:
            pass

    return ime, prezime, godina_rodjenja


def unesi_osobu(osobe):
    print()
    print("Unos osobe...")

    print()

    jmbg = ""
    while jmbg == "" or len(jmbg) != 13 or not jmbg.isdigit() or pronadji_osobu(osobe, jmbg):
        jmbg = input(format_unosa.format("Unesite JMBG"))

    ime, prezime, god_rodjenja = unesi_promenljive_podatke_osobe()
    osoba = {
        "jmbg": jmbg,
        "ime": ime,
        "prezime": prezime,
        "god_rodjenja": god_rodjenja
    }
    osobe[jmbg] = osoba


def izmeni_osobu(osobe):
    print()
    print("Izmena osobe...")

    print()

    osoba = None
    while osoba is None:
        jmbg = input(format_unosa.format("Unesite JMBG"))
        osoba = pronadji_osobu(osobe, jmbg)

    ime, prezime, god_rodjenja = unesi_promenljive_podatke_osobe()
    osoba["ime"] = ime
    osoba["prezime"] = prezime
    osoba["god_rodjenja"] = god_rodjenja


def obrisi_osobu(osobe):
    print()
    print("Brisanje osobe...")

    print()
    jmbg = input(format_unosa.format("Unesite JMBG"))

    osobe.pop(jmbg, None)  # zaobilazi KeyError ako ključ nije ponađen


def napravi_osobu(linija_datoteke):
    podaci = linija_datoteke.split(delimiter)
    osoba = {
        "jmbg": podaci[0],
        "ime": podaci[1],
        "prezime": podaci[2],
        "god_rodjenja": int(podaci[3])
    }

    return osoba


delimiter = ','


def ucitaj_osobe(naziv_datoteke):
    dat = open(naziv_datoteke, "r")
    linije = dat.read().split("\n")
    dat.close()

    osobe = {}
    for linija_datoteke in linije:
        osoba = napravi_osobu(linija_datoteke)
        osobe[osoba["jmbg"]] = osoba

    return osobe


def napravi_liniju(osoba):
    linija_datoteke = delimiter.join([
        osoba["jmbg"],
        osoba["ime"],
        osoba["prezime"],
        str(osoba["god_rodjenja"])
    ])

    return linija_datoteke


def sacuvaj(osobe, naziv_datoteke):
    linije = []
    for jmbg in sorted(osobe):
        osoba = osobe[jmbg]
        linija_datoteke = napravi_liniju(osoba)
        linije.append(linija_datoteke)

    dat = open(naziv_datoteke, "w")
    dat.write("\n".join(linije))
    dat.close()


def izvestaj_1(osobe):
    print()
    print("Izveštaj 1...")

    minimum = float("inf")
    maksimum = float("-inf")
    suma = 0.0
    for jmbg in osobe:
        osoba = osobe[jmbg]

        starost = izracunaj_starost(osoba)
        if starost < minimum:
            minimum = starost
        if starost > maksimum:
            maksimum = starost
        suma += starost

    prosek = suma/len(osobe)

    print()
    print("\n".join([
        "{:>18}: {}".format("Minimalna starost", minimum),
        "{:>18}: {}".format("Prosečna starost", int(prosek)),
        "{:>18}: {}".format("Maksimalna starost", maksimum)
    ]))


def izvestaj_2(osobe):
    print()
    print("Izveštaj 2...")

    broj_osoba = {}
    for jmbg in osobe:
        osoba = osobe[jmbg]

        starost = izracunaj_starost(osoba)
        if starost not in broj_osoba:
            broj_osoba[starost] = 1
        else:
            broj_osoba[starost] += 1

    format_linije = "{:7} {:10}"

    print()
    # zaglavlje
    print(format_linije.format("Starost", "Broj osoba"))
    print("{} {}".format("-"*7, "-"*10))
    # sadržaj
    for starost in sorted(broj_osoba):
        print(format_linije.format(starost, broj_osoba[starost]))


def test():
    osobe = ucitaj_osobe("osobe.csv")
    prikazi_osobe(osobe)

    # unesi_osobu(osobe)
    # prikazi_osobe(osobe)
    #
    # izmeni_osobu(osobe)
    # prikazi_osobe(osobe)
    #
    # obrisi_osobu(osobe)
    # prikazi_osobe(osobe)

    izvestaj_1(osobe)
    izvestaj_2(osobe)

    sacuvaj(osobe, "osobe.csv")


# da li se modul pokreće samostalno, tj. da li nije import-ovan?
if __name__ == "__main__":
    test()
