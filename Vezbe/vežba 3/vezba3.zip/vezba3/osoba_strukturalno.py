from datetime import datetime


godina = datetime.now().year


def starost(osoba):
    return godina - osoba["god_rodjenja"]


def prikazi_osobu(osoba):
    print("\n".join([
        "",
        "{:>12}: {}".format("JMBG", osoba["jmbg"]),
        "{:>12}: {}".format("Ime", osoba["ime"]),
        "{:>12}: {}".format("Prezime", osoba["prezime"]),
        "{:>12}: {}".format("God. rođenja", osoba["god_rodjenja"]),
        "{:>12}: {}".format("Starost", starost(osoba))
    ]))


def prikazi_osobe(osobe):
    format_linije = "{:13} {:10} {:10} {:12} {:7}"

    print()
    # zaglavlje
    print(format_linije.format("JMBG", "Ime", "Prezime", "God. rođenja", "Starost"))
    print("{} {} {} {} {}".format("-"*13, "-"*10, "-"*10, "-"*12, "-"*7))
    # sadržaj
    for osoba in osobe:
        print(format_linije.format(osoba["jmbg"], osoba["ime"], osoba["prezime"], osoba["god_rodjenja"], starost(osoba)))


def test():
    osoba1 = {
        "jmbg": "1111111111111",
        "ime": "Aaa",
        "prezime": "Aaa",
        "god_rodjenja": 2001
    }
    osoba2 = {
        "jmbg": "2222222222222",
        "ime": "Bbb",
        "prezime": "Bbb",
        "god_rodjenja": 2002
    }
    osoba3 = {
        "jmbg": "3333333333333",
        "ime": "Ccc",
        "prezime": "Ccc",
        "god_rodjenja": 2003
    }

    prikazi_osobu(osoba1)
    prikazi_osobu(osoba2)
    prikazi_osobu(osoba3)

    print()
    osoba1["jmbg"] = input("Unesite novi JMBG za osobu 1: ")
    osoba1["ime"] = input("Unesite novo ime za osobu 1: ")
    osoba1["prezime"] = input("Unesite novo prezime za osobu 1: ")
    osoba1["god_rodjenja"] = int(input("Unesite novu godinu rođenja za osobu 1: "))
    print()
    print("Novi JMBG osobe 1 je:", osoba1["jmbg"])
    print("Novo ime osobe 1 je:", osoba1["ime"])
    print("Novo prezime osobe 1 je:", osoba1["prezime"])
    print("Nova godina rođenja osobe 1 je:", osoba1["god_rodjenja"])

    osobe = [
        osoba1,
        osoba2,
        osoba3
    ]
    prikazi_osobe(osobe)


if __name__ == "__main__":
    test()
