from usluge import *

def ucitaj():
    dat = open("nalozi.txt","r")
    usluge = []
    for ucitanalinija in dat.readlines():
        ucitanalinija = ucitanalinija[:-1]

        podaci = ucitanalinija.split("|")

        if podaci[0] == "poziv":
            poziv = Poziv(podaci[1],podaci[2],float(podaci[3]))
            usluge.append(poziv)
        elif podaci[0] == "sms":
            sms = SMS(podaci[1],podaci[2],podaci[3])
            usluge.append(sms)

    dat.close()
    return usluge

def test():

    nalog = Nalog(10.00,1)
    print(nalog)

    print()
    nalog.dodajUsluge( ucitaj() )
    print(nalog)

if __name__ == "__main__":
    test()
