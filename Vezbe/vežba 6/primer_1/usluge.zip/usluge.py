class Usluga:

    def __init__(self, kaBroju, vremeUsluge):
        self.__ka = kaBroju
        self.__vreme = vremeUsluge

    @property
    def ka(self):
        return self.__ka

    @property
    def vreme(self):
        return self.__vreme

    def __str__(self):
        return "ka: "+self.__ka+", vreme: "+self.__vreme

class Poziv(Usluga):

    def __init__(self, kaBroju, vremeUsluge, trajanjePoziva):
        super().__init__(kaBroju,vremeUsluge)
        self.__trajanje = trajanjePoziva

    @property
    def trajanje(self):
        return self.__trajanje

    def __str__(self):
        return super().__str__()+", trajanje: "+str(self.__trajanje)

class SMS(Usluga):

    def __init__(self,ka,vreme, sadrzaj):
        super().__init__(ka, vreme)
        self.__sadrzaj = sadrzaj

    @property
    def sadrzaj(self):
        return self.__sadrzaj

    def __str__(self):
        return super().__str__()+", poruka: "+self.__sadrzaj

class Nalog:

    def __init__(self, besplatniMinuti, besplatniSMSovi):
        self.__listaUsluga = []
        self.__zaduzenje = 0.0
        self.__brojBesplatnihMinuta = float(besplatniMinuti)
        self.__brojBesplatnihSMSova = besplatniSMSovi

    @property
    def listaUsluga(self):
        return self.__listaUsluga

    @property
    def zaduzenje(self):
        return self.__zaduzenje

    @property
    def brojBesplatnihSMSova(self):
        return self.__brojBesplatnihSMSova

    @property
    def brojBesplatnihMinuta(self):
        return self.__brojBesplatnihMinuta

    def dodajUsluge(self,listaUsluga):

        for usluga in listaUsluga:
            self.dodajJednuUslugu(usluga)

    def dodajJednuUslugu(self, usluga):
        if isinstance(usluga, Poziv):
            self.__brojBesplatnihMinuta -= usluga.trajanje
            if self.__brojBesplatnihMinuta<0:
                self.__zaduzenje += (-self.__brojBesplatnihMinuta)*9.00
                self.__brojBesplatnihMinuta = 0.0
        elif isinstance(usluga, SMS):
            self.__brojBesplatnihSMSova-=1
            if self.__brojBesplatnihSMSova<0:
                self.__zaduzenje += 3.00
                self.__brojBesplatnihSMSova = 0

        self.__listaUsluga.append(usluga)

    def __str__(self):
        return "\n".join([
            "usluge",
            "- - - - - - - - - ",
            "\n".join(str(usluga) for usluga in self.__listaUsluga),
            "- - - - - - - - - ",
            "zaduzenje: "+str(self.__zaduzenje),
            "besplatni minuti: "+str(self.__brojBesplatnihMinuta),
            "besplatni SMS: "+str(self.__brojBesplatnihSMSova)
        ])


