class KompleksniBroj:

    def __init__(self,re=0.0,im=0.0):
        self.__re = float(re)
        self.__img = float(im)

    @property
    def re(self):
        return self.__re

    @property
    def img(self):
        return self.__img

    @re.setter
    def re(self,real):
        self.__re=float(real)

    @img.setter
    def img(self,imag):
        self.__img=float(imag)

    def __str__(self):
        if self.__img<0:
            return str(self.__re)+str(self.__img)+"i"
        else:
            return str(self.__re)+"+"+str(self.__img)+"i"
