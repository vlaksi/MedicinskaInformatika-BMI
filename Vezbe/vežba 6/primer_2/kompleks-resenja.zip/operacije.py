from kompleks import KompleksniBroj

class Operacija:

    def __init__(self,naziv,desniOperand):
        self.__naziv = naziv
        self.__desni = desniOperand

    @property
    def naziv(self):
        return self.__naziv

    @property
    def desniOp(self):
        return self.__desni

    def izvrsi(self,levi):
        pass

    def __str__(self):
        return "operacija: "+self.__naziv

# napomena ove operacije prakticno rade tako sto menjaju levi operand
# prakticno implementiraju += i *=
# Ko zeli moze ih prepraviti da prozivode novi Kompl. broj kao rezultat koji bi onda vracale

class Sabiranje(Operacija):

    def izvrsi(self,levi):
        levi.re  = levi.re+super().desniOp.re
        levi.img = levi.img+super().desniOp.img

class Mnozenje(Operacija):

    def izvrsi(self,levi):
        tempRe = levi.re
        tempIm = levi.img
        levi.re = tempRe*self.desniOp.re-tempIm*self.desniOp.img
        levi.img= tempRe*self.desniOp.img+self.desniOp.re*tempIm
