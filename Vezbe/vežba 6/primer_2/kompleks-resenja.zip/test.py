from kompleks import KompleksniBroj
from operacije import *

def ucitaj():

    dat = open("operacije.txt","r")

    operacije = []

    for ucitLinija in dat.readlines():
        ucitLinija = ucitLinija[:-1]
        podaci = ucitLinija.split("|")
        k = KompleksniBroj(podaci[1],podaci[2])
        if podaci[0]=="sabiranje":
            op = Sabiranje(podaci[0],k)
            operacije.append(op)
        elif podaci[0]=="mnozenje":
            op = Mnozenje(podaci[0],k)
            operacije.append(op)

    dat.close()
    return operacije

def test():
    z1 = KompleksniBroj(1,5)
    print(z1)

    z2 = KompleksniBroj(2,-3)
    print(z2)

    op = Sabiranje("sabiranje",z2)
    op.izvrsi(z1)
    print(op)
    print(z1)

    z3 = KompleksniBroj(1,1)
    op1 = Mnozenje("mnozenje",z2)
    print(op1)
    op1.izvrsi(z3)
    print(z3)

    # odavde ide kod koji je u tekstu zadatka

    print(" # # # # # # #\n")
    z = KompleksniBroj(1,1)
    print(z)

    operacije = ucitaj()
    for op in operacije:
        op.izvrsi(z)
        print("\t"+str(z))

    print(z)

if __name__=="__main__":
    test()
