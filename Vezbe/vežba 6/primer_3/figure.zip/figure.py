from transform import Transformacija

class Figura:

    def __init__(self,x=0.0,y=0.0):
        self.__x = float(x)
        self.__y = float(y)

    @property
    def x(self):
        return self.__x

    @property
    def y(self):
        return self.__y

    def __str__(self):
        return "x: "+str(self.__x)+", y: "+str(self.__y)

    def transformisi(self,transformacija):
        self.__x += transformacija.dx
        self.__y += transformacija.dy

    #nije trazeno dodali smo tokom vezbi
    def obim(self):
        pass

    def povrsina(self):
        pass

class Krug(Figura):

    def __init__(self,x=0.0,y=0.0,poluprecnik=1.0):
        super().__init__(x,y)
        self.__poluprecnik = float(poluprecnik)

    @property
    def r(self):
        return self.__poluprecnik

    def __str__(self):
        return super().__str__()+", r="+str(self.__poluprecnik)

    def transformisi(self,transformacija):
        super().transformisi(transformacija)
        self.__poluprecnik*=transformacija.skaliranje

    def obim(self):
        return 2*self.__poluprecnik*3.14159

    def povrsina(self):
        return self.__poluprecnik*self.__poluprecnik*3.14159

class Pravougaonik(Figura):

    def __init__(self,x=0.0,y=0.0,h=1.0,w=1.0):
        super().__init__(x,y)
        self.__h=float(h)
        self.__w=float(w)

    @property
    def visina(self):
        return self.__h

    @property
    def sirina(self):
        return self.__w

    def __str__(self):
        return super().__str__()+", sirina: "+str(self.__w)+", visina: "+str(self.__h)

    def transformisi(self,transformacija):
        super().transformisi(transformacija)
        self.__h *= transformacija.skaliranje
        self.__w *= transformacija.skaliranje

    def obim(self):
        return 2*(self.__h+self.__w)

    def povrsina(self):
        return self.__h*self.__w


