from transform import Transformacija
from figure import *

def ispisiObimiPovrs(figura):
    print("Povrsina: "+str(figura.povrsina())+", obim: "+str(figura.obim()))

def ucitaj():

    dat = open("figure.txt","r")
    figure = []

    for ucitanaLinija in dat.readlines():
        ucitanaLinija = ucitanaLinija[:-1]
        podaci = ucitanaLinija.split("|")
        if podaci[0] == "krug":
            k = Krug(podaci[1],podaci[2],podaci[3])
            figure.append(k)
        elif podaci[0] == "pravougaonik":
            p = Pravougaonik(podaci[1],podaci[2],podaci[3],podaci[4])
            figure.append(p)

    dat.close()
    return figure

def test():
    t  = Transformacija()
    t1 = Transformacija(1.5,2.0,3)
    print (t)
    print(t1)

    k=Krug(2.5,4.5,6)
    print(k)
    k.transformisi(t1)
    print(k)
    ispisiObimiPovrs(k)

    p = Pravougaonik(1,1,2,5)
    print(p)

    ispisiObimiPovrs(p)
    p.transformisi(t1)
    print(p)

    # od ove linije pocinje zahtevani test
    print("###################\n")
    figure = ucitaj()
    t = Transformacija(1.0,-1.0,2.0)

    for f in figure:
        print(f)
        f.transformisi(t)
        print(f)


if __name__ == "__main__":
    test()
