class Transformacija:

    def __init__(self, pomX = 0.0, pomY = 0.0, skala = 1.0):
        self.__dx = pomX
        self.__dy = pomY
        self.__skaliranje = skala

    @property
    def dx(self):
        return self.__dx

    @property
    def dy(self):
        return self.__dy

    @property
    def skaliranje(self):
        return self.__skaliranje

    def __str__(self):
        s = "Transformacija (dx,dy,scale): ("
        s1=", ".join([
            str(self.__dx),
            str(self.__dy),
            str(self.__skaliranje)
        ])
        return s+s1+")"
