from lxml import etree

class Osoba:

    __formatTabele = " {:<13} {:<10} {:10} {:>12} "

    def __init__(self, ime, pre, gr, jmbg):
        self.__ime = ime
        self.__prezime = pre
        self.__godRodj = gr
        self.__jmbg = jmbg

    @property
    def ime(self):
        return self.__ime

    @property
    def prezime(self):
        return self.__prezime

    @property
    def godinaRodjenja(self):
        return self.__godRodj

    @property
    def jmbg(self):
        return self.__jmbg

    def __str__(self):
        return self.__formatTabele.format(
            self.__jmbg,
            self.__ime,
            self.__prezime,
            self.__godRodj
        )

    @classmethod
    def ucitajXML(cls):
        try:

            docXML = etree.parse("osobe.xml")
            listaOsoba = docXML.getroot()
            osobe = {}

            for osoba in listaOsoba:
                ime = osoba[0].text
                prezime = osoba[1].text
                godRodj = osoba[2].text
                jmbg = osoba.attrib["jmbg"]
                osobe[jmbg] = Osoba(ime, prezime, godRodj, jmbg)

            return osobe

        except OSError:
            return {}


