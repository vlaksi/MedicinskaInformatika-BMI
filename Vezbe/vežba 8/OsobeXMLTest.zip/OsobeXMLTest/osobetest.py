from osoba import Osoba

def test():
    persona1 = Osoba("Mile","Milić",1995,"0123456789987")

    print(persona1)

    osobeFromXML = Osoba.ucitajXML()

    for key in osobeFromXML:
        print(osobeFromXML[key])

if __name__ == "__main__":
    test()
