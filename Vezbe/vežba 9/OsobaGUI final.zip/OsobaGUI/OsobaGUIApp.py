from tkinter import *
from osoba import Osoba

class OsobaGuiApp(Tk):

    def __init__(self):
        super().__init__()
        self.napraviGUI()
        self.__spisakOsoba = Osoba.ucitaj()
        self.popuniListu()

    def napraviGUI(self):
        self.__osobeListbox = Listbox(self)
        self.__osobeListbox.pack(side=LEFT, fill=BOTH, expand=1)

        self.__osobeListbox.bind("<<ListboxSelect>>",self.promenaSelekcijeUListi )

        panelZaPrikaz = Frame(self,relief="ridge",padx=10, pady=10, borderwidth=2)
        panelZaPrikaz.pack(side=RIGHT, fill=BOTH, expand=1)

        self.__jmbgLabela = Label(panelZaPrikaz)
        self.__imeLabela  = Label(panelZaPrikaz)
        self.__prezLabela = Label(panelZaPrikaz)
        self.__godRodjLabela = Label(panelZaPrikaz)

        Label(panelZaPrikaz,text="Ime: ").grid(row=0,column=0,sticky=E)
        self.__imeLabela.grid(row=0,column=1,sticky=W)
        Label(panelZaPrikaz,text="Prezime: ").grid(row=1,column=0,sticky=E)
        self.__prezLabela.grid(row=1,column=1,sticky=W)
        Label(panelZaPrikaz,text="JMBG: ").grid(row=2,column=0,sticky=E)
        self.__jmbgLabela.grid(row=2,column=1,sticky=W)
        Label(panelZaPrikaz,text="God. rođ:").grid(row=3,column=0,sticky=E)
        self.__godRodjLabela.grid(row=3,column=1,sticky=W)

        Button(panelZaPrikaz,text="Obriši",width=10, command=self.obrisiLabele).grid(row=4,column=1,sticky=W)

    def popuniListu(self):
        self.__osobeListbox.delete(0,END)
        for jmbg in sorted(self.__spisakOsoba):
            jednaOsoba = self.__spisakOsoba[jmbg]
            ispis = jednaOsoba.ime+" "+jednaOsoba.prezime+", "+jednaOsoba.jmbg
            self.__osobeListbox.insert(END, ispis)

    def promenaSelekcijeUListi(self,event):
        index = self.__osobeListbox.curselection()[0]
        jmbg = sorted(self.__spisakOsoba)[index]
        jednaOsoba = self.__spisakOsoba[jmbg]
        self.popuniLabele(jednaOsoba)

    def popuniLabele(self,osoba):
        self.__jmbgLabela["text"] = osoba.jmbg
        self.__imeLabela["text"]  = osoba.ime
        self.__prezLabela["text"] = osoba.prezime
        self.__godRodjLabela["text"] = osoba.godRodjenja

    def obrisiLabele(self):
        self.__jmbgLabela["text"] = ""
        self.__imeLabela["text"]  = ""
        self.__prezLabela["text"] = ""
        self.__godRodjLabela["text"] = ""


def main():
    mojaApp = OsobaGuiApp()
    mojaApp.mainloop()

main()
