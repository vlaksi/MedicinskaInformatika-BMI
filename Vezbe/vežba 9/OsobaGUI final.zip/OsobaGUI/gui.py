from tkinter import *

from osoba import Osoba

class OsobeProzor(Tk): # Glavni prozor

    # čisti sve labele za prikaz
    def ocistiLabele(self):
        self.__jmbgLabela["text"] = ""
        self.__imeLabela["text"] = ""
        self.__prezimeLabela["text"] = ""
        self.__godRodjenjaLabela["text"] = ""

    # popunjava labele za prikaz vrednostima atributa osobe
    def popuniLabele(self, osoba):
        self.__jmbgLabela["text"] = osoba.jmbg
        self.__imeLabela["text"] = osoba.ime
        self.__prezimeLabela["text"] = osoba.prezime
        self.__godRodjenjaLabela["text"] = str(osoba.godRodjenja)

    def popuniOsobeListbox(self):
        self.__osobeListbox.delete(0, END) # obrisati sve unose iz Listbox-a
        for jmbg in sorted(self.__osobe): # popuniti Listbox u rastućem redosledu vrednosti ključeva rečnika
            osoba = self.__osobe[jmbg]
            ispis = osoba.ime + " " + osoba.prezime + ", " + osoba.jmbg
            self.__osobeListbox.insert(END, ispis)

        self.ocistiLabele() # Listbox će izgubiti prethodnu selekciju; ne želimo da labele prikazuju bilo šta ako ništa nije selektovano

    def klikNaDugmeOcisti(self):
        self.ocistiLabele()

    def promenaSelekcijeUOsobeListbox(self, event):
        if not self.__osobeListbox.curselection(): # ako ništa nije obeleženo u Listbox-u
            self.ocistiLabele()
            return

        # u suprotnom pronaći u rečniku osobu koja odgovara trenutno obeleženom elementu u Listbox-u po njegovom indeksu
        index = self.__osobeListbox.curselection()[0]
        jmbg = sorted(self.__osobe)[index]
        osoba = self.__osobe[jmbg]

        self.popuniLabele(osoba) # popuniti labele vrednostima atributa osobe

    # roditelj većine komponenata (widget-a) bi trebalo da bude panel (Frame), ili prozor (Tk)
    def napraviGUI(self):
        # ako će komponenti morati da se pristupa kasnije, potrebno je sačuvati njenu referencu kao privatni atribut klase
        self.__osobeListbox = Listbox(self) # roditelj Listbox-a u ovom slučaju je glavni prozor
        # pack je jedan od layout manager-a (služi za grubo raspoređivanje komponenata u odnosu na roditelja)
        # jedna roditeljska komponenta ne sme da ima 2 različita layout manager-a; za glavni prozor u ovom slučaju je to pack
        self.__osobeListbox.pack(side = LEFT, fill = BOTH, expand = 1) # Listbox će da zauzme levi deo prozora i moći će da se širi po obe dimenzije; side može imati vrednost (LEFT, RIGHT, TOP, BOTTOM), a fill (X, Y i BOTH)
        # jedan od 2 načina povezivanja callback funkcije sa komponentom
        # 1. parametar je identifikator događaja
        # 2. parametar je callback funkcija
        self.__osobeListbox.bind("<<ListboxSelect>>", self.promenaSelekcijeUOsobeListbox)

        # ako će na komponentu morati da se kače druge komponente, potrebno je sačuvati njenu referencu kao lokalnu promenljivu
        # svaka komponenta je naslednik rečnika; vrednosti se mogu zadati imenovanim argumentima kroz konstruktor, ili direktnom manipulacijom preko istoimenih ključeva u bilo kom momentu
        # panel (Frame) služi za grupisanje komponenata
        panelZaPrikaz = Frame(self, borderwidth = 2, relief = "ridge", padx = 10, pady = 10) # roditelj Frame-a u ovom slučaju je glavni prozor
        panelZaPrikaz.pack(side = RIGHT, fill = BOTH, expand = 1) # panel će da zauzme desni deo prozora i moći će da se širi po obe dimenzije

        # roditelj svih labela u ovom slučaju je panelZaPrikaz
        self.__jmbgLabela = Label(panelZaPrikaz) # labela je komponenta koja može da prikaže proizvoljan tekst i izmenljiva je isključivo programskim putem
        self.__imeLabela = Label(panelZaPrikaz)
        self.__prezimeLabela = Label(panelZaPrikaz)
        self.__godRodjenjaLabela = Label(panelZaPrikaz)

        # grid je jedan od layout manager-a; služi da organizuje komponente po vrstama i kolonama
        # ako se kolona ne navede, podrazumevana je 0-ta kolona
        # jedna roditeljska komponenta ne sme da ima 2 različita layout manager-a; za panelZaPrikaz u ovom slučaju je to grid
        red = 0;
        Label(panelZaPrikaz, text = "JMBG:").grid(row = red, sticky = E); red += 1 # sticky argument određuje horinzotalno poravnanje kolone (E, W), odnosno vertikalno poravnanje reda (N, S)
        Label(panelZaPrikaz, text = "ime:").grid(row = red, sticky = E); red += 1
        Label(panelZaPrikaz, text = "prezime:").grid(row = red, sticky = E); red += 1
        Label(panelZaPrikaz, text = "god. rođenja:").grid(row = red, sticky = E); red += 1

        red = 0; kolona = 1
        self.__jmbgLabela.grid(row = red, column = kolona, sticky = W); red += 1
        self.__imeLabela.grid(row = red, column = kolona, sticky = W); red += 1
        self.__prezimeLabela.grid(row = red, column = kolona, sticky = W); red += 1
        self.__godRodjenjaLabela.grid(row = red, column = kolona, sticky = W); red += 1
        # jedan od 2 načina povezivanja callback funkcije sa komponentom; tipično se koristi za dugmad
        # command argument povezuje callback funkciju sa komponentom
        Button(panelZaPrikaz, text = "Očisti", width = 10, command = self.klikNaDugmeOcisti).grid(row = red, column = kolona, sticky = W); red += 1

        self.title("Osobe") # naslov prozora

    def __init__(self):
        super().__init__()

        self.napraviGUI()

        self.__osobe = Osoba.ucitaj() # rečnik svih osoba; privatni atribut radi pristupa u ostalim metodama
        self.popuniOsobeListbox() # popuniti Listbox

        self.update_idletasks() # između ostalog forsira raspoređivanje komponenata pre prikazivanja prozora; neophodno za izračunavanje min. potrebne širine i visine
        sirina = self.winfo_width()
        visina = self.winfo_height()
        self.minsize(sirina, visina) # prozor ne sme biti manji od min. potrebnih dimenzija
        #self.maxsize(1280, 720)

        self.focus_force() # fokusiran nakon prikazivanja

def main():
    osobeProzor = OsobeProzor() # glavni prozor; jedini se kreira bez roditelja; klasa Tk, ili njena naslednica
    # pokreće pozadinski GUI thread
    # program se ne završava nakon poziva ove funkcije, već traje sve dok se ne zatvori glavni prozor
    osobeProzor.mainloop()

main()
