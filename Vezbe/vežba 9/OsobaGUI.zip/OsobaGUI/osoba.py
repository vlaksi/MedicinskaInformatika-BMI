from lxml import etree

class Osoba:

    __nazivSchemaDokumenta = "osobe.xsd"
    __nazivXMLdokumenta = "osobe.xml"

    __formatTabele = "{:<13} {:<10} {:<10} {:>12}"
    __duplaLinija = "="*48
    __linija = "-"*48

    @property
    def jmbg(self):
        return self.__jmbg

    """
    @jmbg.setter
    def jmbg(self, jmbg):
        self.__jmbg = jmbg
    """

    @property
    def ime(self):
        return self.__ime

    @ime.setter
    def ime(self, ime):
        self.__ime = ime

    @property
    def prezime(self):
        return self.__prezime

    @prezime.setter
    def prezime(self, prezime):
        self.__prezime = prezime

    @property
    def godRodjenja(self):
        return self.__godRodjenja

    @godRodjenja.setter
    def godRodjenja(self, godRodjenja):
        self.__godRodjenja = godRodjenja

    def __init__(self, jmbg = "", ime = "", prezime = "", godRodjenja = 1900):
        self.__jmbg = jmbg
        self.__ime = ime
        self.__prezime = prezime
        self.__godRodjenja = godRodjenja

    def __eq__(self, other):
        return self.__jmbg == other.__jmbg

    def __str__(self):
        return "\n".join([
            "{:>12}: {}".format("JMBG", self.__jmbg),
            "{:>12}: {}".format("ime", self.__ime),
            "{:>12}: {}".format("prezime", self.__prezime),
            "{:>12}: {}".format("god. rođenja", self.__godRodjenja)])

    def uvecajGodRodjenja(self, zaKoliko=1):
        self.__godRodjenja = self.__godRodjenja + zaKoliko

    @classmethod
    def vratiIzElementa(_class, element):
        jmbg = element.attrib["jmbg"]
        ime = element[0].text
        prezime = element[1].text
        godRodjenja = int(element[2].text)

        osoba = _class(jmbg, ime, prezime, godRodjenja)
        return osoba

    def napraviElement(self):
        element = etree.Element("osoba")
        element.append(etree.Element("ime"))
        element.append(etree.Element("prezime"))
        element.append(etree.Element("godRodjenja"))

        element.attrib["jmbg"] = self.__jmbg
        element[0].text = self.__ime
        element[1].text = self.__prezime
        element[2].text = str(self.__godRodjenja)
        return element

    @classmethod
    def ucitaj(_class):
        try:
            xmlDoc = etree.parse(_class.__nazivXMLdokumenta)

            schemaDoc = etree.parse(_class.__nazivSchemaDokumenta)
            schema = etree.XMLSchema(schemaDoc)
            if not schema.validate(xmlDoc):
                print(schema.error_log)
                return {}

            osobe = {}

            osobeElement = xmlDoc.getroot()
            for osobaElement in osobeElement:
                osoba = _class.vratiIzElementa(osobaElement)
                osobe[osoba.jmbg] = osoba

            return osobe
        except OSError:
            return {}

    @classmethod
    def sacuvaj(_class, osobe):
        namespaces = {"xsi" : "http://www.w3.org/2001/XMLSchema-instance"}
        attributes = {"{http://www.w3.org/2001/XMLSchema-instance}noNamespaceSchemaLocation": _class.__nazivSchemaDokumenta}

        osobeElement = etree.Element("osobe", attributes, namespaces)
        for jmbg in sorted(osobe.keys()):
            osoba = osobe[jmbg]
            osobaElement = _class.napraviElement(osoba)
            osobeElement.append(osobaElement)

        xmlDoc = etree.ElementTree(osobeElement)

        schemaDoc = etree.parse(_class.__nazivSchemaDokumenta)
        schema = etree.XMLSchema(schemaDoc)
        if not schema.validate(xmlDoc):
            print(schema.error_log)
            return

        datoteka = open(_class.__nazivXMLdokumenta, "wb")
        xmlDoc.write(datoteka, encoding = "UTF-8", xml_declaration = True, pretty_print = True)
        datoteka.close()

    @classmethod
    def napraviTabelu(_class, osobe):
        tabela = []
        tabela.append(_class.__formatTabele.format("JMBG", "ime", "prezime", "god. rođenja"))
        tabela.append(_class.__duplaLinija)
        for jmbg in sorted(osobe):
            osoba = osobe[jmbg]
            tabela.append(_class.__formatTabele.format(
                osoba.jmbg,
                osoba.ime,
                osoba.prezime,
                osoba.godRodjenja))
            tabela.append(_class.__linija)

        return "\n".join(tabela)

def test():
    osoba1 = Osoba("1111111111111", "aa", "aa", 2001)
    osoba2 = Osoba("2222222222222", "bb", "bb", 2002)
    osoba3 = Osoba("3333333333333", "cc", "cc", 2003)

    osobe = {}
    osobe[osoba1.jmbg] = osoba1
    osobe[osoba2.jmbg] = osoba2
    osobe[osoba3.jmbg] = osoba3

    print(Osoba.napraviTabelu(osobe))

    print()
    print("cuvanje...")
    Osoba.sacuvaj(osobe)

    print()
    print("ucitavanje...")
    osobe = Osoba.ucitaj()

    print()
    print(Osoba.napraviTabelu(osobe))

if __name__ == "__main__":
    test()
